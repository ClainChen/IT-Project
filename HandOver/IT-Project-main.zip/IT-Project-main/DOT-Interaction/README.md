# Unity QR code Scanner

This is a simple implementation of QR Code Scanner in Unity. Build for Android/iOS/Windows.
